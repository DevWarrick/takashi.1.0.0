import { useEffect } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Navbar from "../navbar/navbar";

// imported images
import takashi1 from "../../images/takashi-1.jpg";
import takashi2 from "../../images/takashi-2.jpg";
import takashi3 from "../../images/takashi-3.jpg";

import "./website.css";

gsap.registerPlugin(ScrollTrigger);

const Website = () => {
  useEffect(() => {
    gsap.utils.toArray(".fade-in").forEach((element) => {
      gsap.from(element, {
        opacity: 0,
        y: 50,
        duration: 1,
        scrollTrigger: {
          trigger: element,
          start: "top 80%",
          end: "bottom 20%",
          scrub: true, // Add scrub to sync animation with scroll
          toggleActions: "play none none none",
        },
      });
    });
  }, []);

  const backgroundStyle = {
    backgroundImage: `url(${takashi2})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
  };

  return (
    <div className="website-container">
      {/* Navbar */}
      <Navbar />

      {/* Hero Section */}
      <div className="hero-container">
        <img className="takashi-1" src={takashi1} alt="Takashi" />
      </div>

      {/* About Section */}
      <div className="about-container">
        <div className="spacing">
          <h2 className="fade-in">About Takashi</h2>
          <p className="fade-in">
            In a vibrant digital landscape, Shogun Takashi ruled with honor and
            vision. He was not just a warrior; he was a unifying force for the
            largest crypto community, built on the values of love for
            cryptocurrency and the bonds of family.
          </p>

          <p className="fade-in">
            Members gathered online, sharing stories and strategies, forging
            connections that felt more like kinship than mere transactions.
            Takashilebrated milestones together, supporting one another through
            market highs and lows. Takashi, a symbol of resilience, encouraged
            them to see their investments not just as currency, but as a shared
            journey.
          </p>

          <p className="fade-in">
            As the community thrived, they organized events to help families in
            need, using their crypto gains to make a real-world impact. Through
            love, loyalty, and the spirit of togetherness, they transformed the
            digital realm into a sanctuary where every member felt valued and
            connected, just like family.
          </p>
        </div>
        {/* Coin Details */}
        <div className="coin-details" style={backgroundStyle}>
          {/* Details */}
          <div className="coin-info">
            {/* Coin Name */}
            <div className="coin-details-containers">
              <h3 className="coin-details-containers-header">Name</h3>
              <span className="coin-details-text">Takashi</span>
            </div>
            {/* Coin Symbol */}
            <div className="coin-details-containers">
              <h3 className="coin-details-containers-header">Symbol</h3>
              <span className="coin-details-text">TAK</span>
            </div>
            {/* Coin Supply */}
            <div className="coin-details-containers">
              <h3 className="coin-details-containers-header">Total Supply</h3>
              <span className="coin-details-text">1,000,000,000</span>
            </div>
            {/* Token Address */}
            <div className="coin-details-containers">
              <h3 className="coin-details-containers-header">Token Address</h3>
              <span className="coin-details-text">
                The Token Address goes here
              </span>
            </div>
          </div>
        </div>

        {/* How to Buy */}

        {/* Social Media */}
        {/* <h2>Join the Takashi Family</h2> */}
      </div>
      {/* Sticky Footer */}
      <div className="sticky-footer">
        <div className="sticky-footer-container">
          <a href="#" target="_blank">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="32"
              height="32"
              fill="currentColor"
              className="bi bi-telegram"
              viewBox="0 0 16 16"
            >
              <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0M8.287 5.906q-1.168.486-4.666 2.01-.567.225-.595.442c-.03.243.275.339.69.47l.175.055c.408.133.958.288 1.243.294q.39.01.868-.32 3.269-2.206 3.374-2.23c.05-.012.12-.026.166.016s.042.12.037.141c-.03.129-1.227 1.241-1.846 1.817-.193.18-.33.307-.358.336a8 8 0 0 1-.188.186c-.38.366-.664.64.015 1.088.327.216.589.393.85.571.284.194.568.387.936.629q.14.092.27.187c.331.236.63.448.997.414.214-.02.435-.22.547-.82.265-1.417.786-4.486.906-5.751a1.4 1.4 0 0 0-.013-.315.34.34 0 0 0-.114-.217.53.53 0 0 0-.31-.093c-.3.005-.763.166-2.984 1.09" />
            </svg>
          </a>

          <a href="https://x.com/Takashi_sol?s=08" target="_blank">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="32"
              height="32"
              fill="currentColor"
              className="bi bi-twitter-x"
              viewBox="0 0 16 16"
            >
              <path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865z" />
            </svg>
          </a>
        </div>
      </div>
    </div>
  );
};

export default Website;
