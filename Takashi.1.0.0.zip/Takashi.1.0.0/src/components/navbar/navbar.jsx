import "./navbar.css";

const Navbar = () => {
  return (
    <div className="navbar">
      <nav>
        <div className="logo">
          <span>Takashi</span>
        </div>

        <div className="link-container">
          {/* <a href="https://raydium.io/" target="_blank" className="buy-link">
            Buy Now
          </a> */}
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
