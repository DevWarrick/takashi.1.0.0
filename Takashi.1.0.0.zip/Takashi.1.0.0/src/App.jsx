import ReactDOM from "react-dom/client";
import Website from "./components/website/website";

const App = () => {
  return (
    <div>
      <Website />
    </div>
  );
};

const container = document.getElementById("root");
const root = ReactDOM.createRoot(container);
root.render(<App />);
